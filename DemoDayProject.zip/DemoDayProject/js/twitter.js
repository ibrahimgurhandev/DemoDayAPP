const Twitter = require("twitter")
const dotenv = require("dotenv")
const fs = require("fs")

dotenv.config()

function publish_tweet(content,image,token,secret)
{
    const client = new Twitter({
        consumer_key: process.env.CONSUMER_KEY,
        consumer_secret: process.env.CONSUMER_SECRET,
        access_token_key: token,
        access_token_secret: secret
    })

    if(image === "no_image")
    {
        client.post('statuses/update', {status: content},  function(error, tweet, response) {
            
            console.log(tweet); 
            console.log(response);
        });
    }else{
        const imageData = fs.readFileSync("./"+image);
        client.post("media/upload", {media: imageData}, function(error, media, response) {
            if (error) {
                console.log(error)
            } else {
                const post_status = {
                    status: content,
                    media_ids: media.media_id_string
                }

                client.post("statuses/update", post_status, function(error, tweet, response) {
                    if (error) {
                        console.log(error);
                    } else {
                        console.log("Successfully tweeted an image!")
                    }
                })
            }
        })
    }
}

module.exports = {publish_tweet};

