const express = require('express');
const ejs = require('ejs');
const path = require('path');
var session = require('express-session');
var bodyParser = require('body-parser');
const app = express();
const admin = require('firebase-admin');
const tweet_customize = require('./js/customize.js');
const tweet_engine = require('./js/twitter.js');
var serviceAccount = require('./firebase.json');
var posts;

admin.initializeApp({
	credential: admin.credential.cert(serviceAccount),
	databaseURL: "https://cronoify.firebaseio.com",
	authDomain: "cronofy-tweet-app.firebaseapp.com",
});

const db = admin.database();

function date_format(date_val) {
	if (date_val < 10) {
		date_val = "0" + date_val;
	}
	return date_val;
}

app.set('view engine', 'ejs');
app.use(express.static('public'))
// app.use(express.static(__dirname + '/assets'));
app.use(express.json());
app.use(express.urlencoded());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
	extended: true
}));

app.use(session({
	secret: 'user_sess7821639812374192834'
}));

app.use('/css', express.static('css'));
app.use(express.static('public'))
app.use('/js', express.static('js'));
app.use('/assets/media', express.static('assets/media'));


app.get('/loginc', function (req, res) {
	if (req.session.user_name) {
		res.redirect("./dashboard");
	} else {
		res.render('login');
	}
});


app.get('/', function(req, res) {
	res.render('home.ejs');
});


app.get('/login', function(req, res) {
	res.render('login.ejs');
});


app.get('/login2', function(req, res) {
	res.render('login2.ejs');
});


app.get('/dashboard', function (req, res) {
	
	if (req.session.user_name) {
		const ref = db.ref(req.session.user_name + "_post");
		ref.on("value", function (snapshot) {
			posts = JSON.stringify(snapshot.val());
		}, function (errorObject) {
			posts = {};
			posts = JSON.stringify(posts);
		});
		
		res.render('index', {
			session: req.session,
			posts: posts
		});
	} else {
		res.redirect("./");
	}
});

app.post('/tweet_login', function (req, res) {

	const ref = db.ref("user/" + req.body.user_name);
	ref.on("value", function (snapshot) {
		ref.update({
			name: req.body.user_name,
			photo: req.body.user_photo,
			token: req.body.token,
			secret: req.body.secret,
		});
	}, function (errorObject) {
		ref.push({
			name: req.body.user_name,
			photo: req.body.user_photo,
			token: req.body.token,
			secret: req.body.secret,
		});
	});
	req.session.user_name = req.body.user_name;
	req.session.user_photo = req.body.user_photo;
	req.session.token = req.body.token;
	req.session.token_secret = req.body.secret;
	res.send("return");
});

app.get("/tweet_logout", function (req, res) {
	req.session.destroy();
	res.redirect("/");
})

app.post('/upload', (req, res) => {
	if (req.session.user_name) {
		tweet_customize.upload(req, res, (err) => {
			if (err) {
				res.redirect("./dashboard");
			} else {
				var post_date_time = req.body.post_date+" "+req.body.post_time;
				if (req.file == undefined) {
					const ref = db.ref(req.session.user_name + "_post");
					ref.push({
						post_text: req.body.post_text,
						post_date: post_date_time,
						post_path: "no_image",
						status: 0,
					});
				} else {
					const ref = db.ref(req.session.user_name + "_post");
					ref.push({
						post_text: req.body.post_text,
						post_date: post_date_time,
						post_path: req.file.path,
						status: 0,
					});
				}
				res.redirect("./dashboard");
			}
		});
	} else {
		res.redirect("./");
	}
});

app.post('/tweet_del', function (req, res) {
	const ref = db.ref(req.session.user_name + "_post");
	ref.child(req.body.post_id).remove();
	res.redirect('./dashboard');
});

app.post('/tweet_update', function (req, res) {
	const ref = db.ref(req.session.user_name + "_post/" + req.body.post_id);
	ref.on("value", function (snapshot) {
		ref.update({
			post_date: req.body.post_date,
			post_text: req.body.post_text,
		});
	}, function (errorObject) {

	});
	res.redirect("./dashboard");
});

var cron = require('node-cron');
// const shell = require('shelljs')


var task = cron.schedule('*/5 * * * * *', () => {
	console.log('running')
					
	const ref = db.ref("user"); // we load user table
	ref.on("value", function (snapshot) {
		var user_array = snapshot.val();
		for (var index in user_array) {
			const ref_post = db.ref(index + "_post"); // bob_post
			ref_post.on("value", function (snapshot) {
				var post_array = snapshot.val();

				for (var index_post in post_array) {
					var new_date = new Date();
					var year = new_date.getFullYear();
					var month = date_format(new_date.getMonth() + 1);
					var date = date_format(new_date.getDate());
					var hour = date_format(new_date.getHours());
					var minute = date_format(new_date.getMinutes());
					var second = date_format(new_date.getSeconds()); //2020-10-05 09:08:30
					var today = year + "-" + month + "-" + date + " " + hour + ":" + minute + ":" + second;
					var post_date = post_array[index_post]['post_date']+":00";
					
				
					var compare = today.localeCompare(post_date);
					if (compare == 1 && post_array[index_post]['status'] == 0) {
						const ref_update = db.ref(index + "_post/" + index_post);
						ref_update.update({
							status: 1,
						});
						tweet_engine.publish_tweet(post_array[index_post]['post_text'], post_array[index_post]['post_path'], user_array[index]['token'], user_array[index]['secret']);
						
					}
				}
			})
		}
	}, function (errorObject) {

	});
})

task.start()


const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Server started on port ${port}`));